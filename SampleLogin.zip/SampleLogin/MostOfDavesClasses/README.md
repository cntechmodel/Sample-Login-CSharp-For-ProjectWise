# MostOfDavesClasses-CSharp-Wrappers-For-ProjectWise
These are the classes I use to wrap the ProjectWise native code API. I have taken to just including MostOfDavesClass.cs in my projects.
