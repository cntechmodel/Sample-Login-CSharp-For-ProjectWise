﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;


namespace SampleLogin
{
    class ProgramSimpleLogin
    {
        private static string sDatasourceName;
        private static string sUserName;
        private static string sPassword;

        private static void GetApplicationDefaultProperties()
        {
            sDatasourceName = Properties.Settings.Default.DataSource.Trim();
            sUserName = Properties.Settings.Default.Username.Trim();
            sPassword = Properties.Settings.Default.Password.Trim();
        }

        private static void GetUserSpecifiedValuesFromCommandLine(string[] args)
        {
            bool ShowUsageMessage = false;

            for (var argIndex = 0; argIndex < args.Length; argIndex++)
                if (args[argIndex].ToLower() == "-d")
                {
                    sDatasourceName = args[++argIndex];
                }
                else if (args[argIndex].ToLower() == "-u")
                {
                    sUserName = args[++argIndex];
                }
                else if (args[argIndex].ToLower() == "-p")
                {
                    sPassword = args[++argIndex];
                }
                else if (args[argIndex].ToLower() == "-?")
                {
                    ShowUsageMessage = true;
                }
                else
                {
                    ShowUsageMessage = true;
                    Console.WriteLine("[Error  ] Invalid command line argument '{0}'", args[argIndex]);
                }

            if (ShowUsageMessage)
                ShowUsageAndExit();
        }

        public static void ShowPWError()
        {
            Console.WriteLine("[{0}]\n{1}\n{2}",
                    PWWrapper.aaApi_GetLastErrorId(),
                    PWWrapper.aaApi_GetLastErrorMessage(),
                    PWWrapper.aaApi_GetLastErrorDetail());
        }

        public static void ShowUsageAndExit()
        {
            Console.WriteLine("");
            Console.WriteLine("======");
            Console.WriteLine("Usage:");
            Console.WriteLine("======");
            Console.WriteLine("{0} [-d Server:Datasource] [-u Username] [-p Password]", Process.GetCurrentProcess().ProcessName);
            Console.WriteLine("------");
            Console.WriteLine("Notes:");
            Console.WriteLine("------");
            Console.WriteLine("Command line arguments override the values in {0}.config.", Process.GetCurrentProcess().ProcessName);
            Console.WriteLine("");

            ExitApp(-1);
        }

        public static void ExitApp(int ExitCode)
        {
            // When in the debugger, the console window will stay open.
            if (Debugger.IsAttached)
            {
                Console.Write("Press any key to exit console window when in debug mode...");
                Console.ReadKey();
            }

            Environment.Exit(ExitCode);
        }

        static void Main(string[] args)
        {
            GetApplicationDefaultProperties();

            GetUserSpecifiedValuesFromCommandLine(args);

            // Initialize the PW APIs
            PWWrapper.aaApi_Initialize(0);

            // Before we login, we can check to see what version of ProjectWise are we using.
            // This will be the version of ProjectWise Explorer on this machine.
            Int32 MajorHigh = 0;
            Int32 MajorLow = 0;
            Int32 MinorVersion = 0;
            Int32 BuildNo = 0;

            if (!PWWrapper.aaApi_GetAPIVersion(ref MajorHigh, ref MajorLow, ref MinorVersion, ref BuildNo))
            {
                // In generaly, it is a good practice to check if a method worked or not
                ShowPWError();
                PWWrapper.aaApi_Uninitialize(); // good practice
                ExitApp(-2);
            }
            else
            {
                Console.WriteLine("ProjectWise Explorer Version {0}.{1}.{2}.{3}", MajorHigh, MajorLow, MinorVersion, BuildNo);
            }

            try
            {
                using (PWSession myPWSession = new PWSession(sDatasourceName, sUserName, sPassword))
                {
                    // Determine who has logged in.
                    int userId = PWWrapper.aaApi_GetCurrentUserId();
                    if (userId == 0)
                    {
                        ShowPWError();
                        PWWrapper.aaApi_LogoutByHandle(PWWrapper.aaApi_GetActiveDatasource()); // good practice
                        PWWrapper.aaApi_Uninitialize(); // good practice
                        ExitApp(-4);
                    }
                    else
                    {
                        Console.WriteLine("Logged into Datasource '{0}' with Username '{1}' successfully.",
                            sDatasourceName,
                            sUserName);

                        // get some info about the current user
                        if (PWWrapper.aaApi_SelectUser(userId) != 1)
                        {
                            ShowPWError();
                        }
                        else
                        {
                            Console.WriteLine("User id={0}, Name='{1}', Description='{2}', Email='{3}'",
                                userId,
                                PWWrapper.aaApi_GetUserStringProperty(PWWrapper.UserProperty.Name, 0),
                                PWWrapper.aaApi_GetUserStringProperty(PWWrapper.UserProperty.Desc, 0),
                                PWWrapper.aaApi_GetUserStringProperty(PWWrapper.UserProperty.Email, 0));
                        }
                    }

                    // A good practice is to Logout and unitialize
                    if (!PWWrapper.aaApi_LogoutByHandle(PWWrapper.aaApi_GetActiveDatasource()))
                    {
                        ShowPWError();
                        ExitApp(-5);
                    }
                    else
                    {
                        Console.WriteLine("Logged out.");
                        PWWrapper.aaApi_Uninitialize(); // good practice
                    }

                }

            }
            catch (Exception ex)
            {
                // using the Exception message
                Console.WriteLine(ex.Message);

                // optionally
                Console.WriteLine("StackTrace: {0}", ex.StackTrace);

                // no point in continuing 
                ExitApp(-3);
            }

            // All done, but we want to keep the console window open in debug mode...
            ExitApp(0);
        }
    }
}
